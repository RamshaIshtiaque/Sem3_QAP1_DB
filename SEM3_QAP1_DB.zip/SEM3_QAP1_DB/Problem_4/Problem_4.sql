{\rtf1\ansi\ansicpg1252\cocoartf2709
\cocoatextscaling0\cocoaplatform0{\fonttbl\f0\fswiss\fcharset0 Helvetica;}
{\colortbl;\red255\green255\blue255;\red0\green0\blue0;\red255\green255\blue255;\red39\green129\blue201;
\red255\green255\blue255;\red20\green152\blue106;\red42\green49\blue64;}
{\*\expandedcolortbl;;\cssrgb\c0\c0\c0;\cssrgb\c100000\c100000\c100000;\cssrgb\c18039\c58431\c82745;
\cssrgb\c100000\c100000\c100000;\cssrgb\c0\c65098\c49020;\cssrgb\c21569\c25490\c31765;}
\margl1440\margr1440\vieww11520\viewh8400\viewkind0
\deftab720
\pard\pardeftab720\partightenfactor0

\f0\fs22 \cf2 \cb3 \expnd0\expndtw0\kerning0
\outl0\strokewidth0 \strokec4 INSERT\strokec5  \strokec4 INTO\strokec5  public.authors (author_name)\
\strokec4 VALUES\strokec5  (\strokec6 'Colleen Hoover'\strokec5 ), (\strokec6 'Jodi Picoult'\strokec5 ), (\strokec6 'Emily Henry'\strokec5 );\cf7 \cb1 \strokec7 \
\pard\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\pardirnatural\partightenfactor0
\cf0 \kerning1\expnd0\expndtw0 \outl0\strokewidth0 \
INSERT INTO public.books (book_title , author_id)\
VALUES \
('It Ends With Us' , '1'),\
('Book Lovers' , '3'),\
('Handle With Care' , '2'),\
('November 9' , '1');\
}