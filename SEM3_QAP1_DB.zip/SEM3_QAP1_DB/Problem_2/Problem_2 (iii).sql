{\rtf1\ansi\ansicpg1252\cocoartf2709
\cocoatextscaling0\cocoaplatform0{\fonttbl\f0\fnil\fcharset0 Monaco;\f1\fswiss\fcharset0 Helvetica;}
{\colortbl;\red255\green255\blue255;\red0\green0\blue0;\red255\green255\blue255;\red39\green129\blue201;
\red255\green255\blue255;\red226\green131\blue14;}
{\*\expandedcolortbl;;\cssrgb\c0\c0\c0;\cssrgb\c100000\c100000\c100000;\cssrgb\c18039\c58431\c82745;
\cssrgb\c100000\c100000\c100000;\cssrgb\c91373\c58431\c4706;}
\margl1440\margr1440\vieww11520\viewh8400\viewkind0
\deftab720
\pard\pardeftab720\partightenfactor0

\f0\fs22 \cf2 \cb3 \expnd0\expndtw0\kerning0
\outl0\strokewidth0 \strokec4 SELECT\strokec5  \strokec6 COUNT\strokec5 (city) \strokec4 AS\strokec5  city_count, country_id\
\strokec4 FROM\strokec5  city\
\strokec4 GROUP\strokec5  \strokec4 BY\strokec5  country_id\
\strokec4 ORDER\strokec5  \strokec4 BY\strokec5  city_count \strokec4 DESC\strokec5 ;
\f1\fs24 \cf0 \cb1 \kerning1\expnd0\expndtw0 \outl0\strokewidth0 \
}